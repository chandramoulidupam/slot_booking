service_interface_template = """{% autoescape off %}class ServiceInterface:

    @staticmethod
    def get_user_id_from_username():
        pass


{% endautoescape %}"""
