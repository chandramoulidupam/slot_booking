def endpoint_response(response_obj, response_status_code=200, response_headers_obj=None):
    return response_status_code, response_obj, response_headers_obj
