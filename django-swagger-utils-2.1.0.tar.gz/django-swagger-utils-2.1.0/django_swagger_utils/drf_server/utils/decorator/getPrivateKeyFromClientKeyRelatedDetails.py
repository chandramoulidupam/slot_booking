__author__ = 'anush0247'


def getPrivateKeyFromClientKeyRelatedDetails(clientId):
    return -1
