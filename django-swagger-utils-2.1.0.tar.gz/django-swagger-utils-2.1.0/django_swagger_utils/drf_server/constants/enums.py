from enum import Enum


class CleanCodeViewsTestsVersion(Enum):
    VERSION_ZERO = "0.0"
    VERSION_ONE = "1.0"
